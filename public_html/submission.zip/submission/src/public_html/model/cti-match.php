<?php
    namespace CTI;

    class CtiMatch {
        private $matchedValues;
    }
?>