<?php
namespace CTI;
require_once './components/component.php';

interface Page extends Component {
	
	public function update();
}
?>