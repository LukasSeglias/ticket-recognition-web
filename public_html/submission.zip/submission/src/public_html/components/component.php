<?php
namespace CTI;

interface Component {
	
	public function template();
	public function context();
}
?>